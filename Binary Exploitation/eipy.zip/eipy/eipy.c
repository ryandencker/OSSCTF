#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void print_flag() {
    char buf[64];
    FILE *f = fopen("flag.txt","r");
    if (f == NULL) {
        exit(0);
    }

    fgets(buf,64,f);
    printf(buf);
}

void vuln() {
    char buffer[64];
    printf("Enter your input: ");
    gets(buffer); // Vulnerable function
    printf("You entered: %s\n", buffer);
}

int main() {
    setbuf(stdout, NULL); // Disable output buffering for easier exploitation
    printf("this buffer overflow is eipy\n");
    vuln();
    return 0;
}
