#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void spit_on_that_thang() {
    char flag[64];
    FILE *file = fopen("flag.txt", "r");
    if (file == NULL) {
        printf("Error: Could not open flag file.\n");
        exit(1);
    }
    fgets(flag, sizeof(flag), file);
    fclose(file);
    printf("Hawk Tuah! You spit on that thang real good: %s\n", flag);
}

void hawk_tuah() {
    char buffer[32];
    printf("Try to spit_on_that_thang: ");
    gets(buffer);
    printf("Your hawk_tuah: %s\n", buffer);
}

int main() {
    printf("Welcome to hawk tuAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA!\n\n");
    printf("During the video, she was asked a series of adult questions including, What's one move in bed that makes a man go crazy every time? Welchs reply, in a hard Southern Twang accent, was, You gotta give em that hawk tuah and spit on that thang, referring to spitting on a mans penis during oral sex.\n\n");
    hawk_tuah();
    return 0;
}
